#include <stdio.h>
#include <string.h>             //strlen
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>             //close
#include <arpa/inet.h>          //close
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/time.h>           //FD_SET, FD_ISSET, FD_ZERO macros
#include <curl/curl.h>
#include "curlrtns.h"

#if 0
#define TRUE 1
#define FALSE 0
#define PORT 8888

#define OK 1
#define NOTOK !OK


struct string {
    char *ptr;
    size_t len;
};
#endif


void init_string(struct string *s)
{
    s->len = 0;
    s->ptr = malloc(s->len + 1);
    if (s->ptr == NULL) {
	fprintf(stderr, "malloc() failed\n");
	exit(EXIT_FAILURE);
    }
    s->ptr[0] = '\0';
}

size_t writefunc(void *ptr, size_t size, size_t nmemb, struct string *s)
{
    size_t new_len = s->len + size * nmemb;
    s->ptr = realloc(s->ptr, new_len + 1);
    if (s->ptr == NULL) {
	fprintf(stderr, "realloc() failed\n");
	exit(EXIT_FAILURE);
    }
    memcpy(s->ptr + s->len, ptr, size * nmemb);
    s->ptr[new_len] = '\0';
    s->len = new_len;

    return size * nmemb;
}

int exec_superhero_api(char *search_str, struct string *s)
{
    CURL *curl;
    CURLcode res;
    char api_url[1024];
    strcpy(api_url,
	   "https://www.superheroapi.com/api.php/163220391589190");

    //printf("SearchString : %s\n", search_str);
    strcat(api_url, search_str);
    //printf("Connect URI: %s\n", api_url);

    curl = curl_easy_init();
    if (curl) {
	struct curl_slist *chunk = NULL;

	chunk = curl_slist_append(chunk, "X-silly-header;");
	curl_easy_setopt(curl, CURLOPT_HTTPHEADER, chunk);

	curl_easy_setopt(curl, CURLOPT_URL, api_url);
	curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writefunc);
	curl_easy_setopt(curl, CURLOPT_WRITEDATA, s);
	curl_easy_setopt(curl, CURLOPT_HTTP_VERSION,
			 (long) CURL_HTTP_VERSION_2);

	res = curl_easy_perform(curl);

	if (res != CURLE_OK) {
	    fprintf(stderr, "curl_easy_perform() failed: %s\n",
		    curl_easy_strerror(res));
	    return (NOTOK);
	}
	//printf("%s\n", s.ptr);
	//free(s.ptr);

	curl_easy_cleanup(curl);
    }

    return (OK);
}

