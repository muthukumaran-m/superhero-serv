#define TRUE 1
#define FALSE 0
#define PORT 8888

#define OK 1
#define NOTOK !OK


struct string {
    char *ptr;
    size_t len;
};


int exec_superhero_api(char *search_str, struct string *s);
void init_string(struct string *s);
size_t writefunc(void *ptr, size_t size, size_t nmemb, struct string *s);

