#include <stdio.h>
#include <stdlib.h>
#include "httpd.h"
#include "curlrtns.h"

int main(int c, char** v)
{
    serve_forever("8888");
    return 0;
}

void route(char req_uri[256])
{
    struct string s;
    init_string(&s);

    exec_superhero_api(req_uri, &s);
    printf("HTTP/1.1 200 OK\r\n\r\n");
    printf("%s", s.ptr);
    free(s.ptr);

#if 0
    ROUTE_START()

    ROUTE_GET("/")
    {
        printf("HTTP/1.1 200 OK\r\n\r\n");
        printf("Hello! You are using %s", request_header("User-Agent"));
	printf("URI : %s", req_uri);
        printf("Marikannan : %s", s.ptr);
        free(s.ptr);
    }

    ROUTE_POST("/")
    {
        printf("HTTP/1.1 200 OK\r\n\r\n");
        printf("Wow, seems that you POSTed %d bytes. \r\n", payload_size);
        printf("Fetch the data using `payload` variable.");
    }
  
    ROUTE_END()
#endif
}

